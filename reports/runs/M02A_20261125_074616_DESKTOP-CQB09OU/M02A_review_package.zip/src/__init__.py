"""krkCMd modular source package."""
