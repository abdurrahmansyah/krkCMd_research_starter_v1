# Laporan Hasil Run 11 — M04A: Screening Ilmiah Pertama pada Data `krkCMd` Asli

- **Run ID:** `M04A_20261126_145808_DESKTOP-CQB09OU`
- **Status Fase:** **PARTIAL (20/23 kandidat `PASS`; 3/23 `FAILED` batas waktu `3.600 dtk`; 0 kebocoran data test)**
- **Keputusan yang Disetujui:** `D-009A` s.d. `D-009J` (`docs/DECISIONS.md`)
- **Batas Data:** Hanya partisi `train` (`12.216` baris / `2.036` grup) dan `validation` (`3.060` baris / `510` grup) Protocol A dengan `seed=42`. Partisi `test` (`3.822` baris) disegel penuh (`test_rows_exposed_to_worker = 0`).

---

## 1. Ringkasan Eksekusi & Status Kandidat

- **Berhasil (`20 / 23` target M04A):** `ML01–ML07`, `DL01–DL05`, `FM03`, `SG01`, `SG04`, `SG05`, `SG06`, `RF01`, `RF02`, `RF05`. Seluruhnya menghasilkan tepat `3.060` prediksi validasi dengan selisih rekomputasi MAE/RMSE `0.0`.
- **Gagal Batas Komputasi (`3 / 23`):**
  - `SG02` (`ResNet-1D`, TF CPU-only Windows): `WALL_CLOCK_TIMEOUT (3600s)`.
  - `SG03` (`InceptionTime`, TF CPU-only Windows, `n_regressors=1` single-member): `WALL_CLOCK_TIMEOUT (3600s)`.
  - `FM04` (`TabDPT`, `.venv-foundation`): Percobaan 1 gagal `TypeError` (`seed` di `predict`); Percobaan 2 (`_r2`, `batch_size=None`) gagal `GPU_VRAM_BUDGET_EXCEEDED (22339.0 MiB > 19291.6 MiB)`; Percobaan 3 (`_r3`, `batch_size=128`) gagal `WALL_CLOCK_TIMEOUT (3600s) [SUSPEND_DETECTED]` pada `3.601,484 dtk`.
- **Dipertahankan di Registry (`9 / 32` non-M04A):** `FM01`, `FM02` (`BLOCKED_LICENSE`), `RF03`, `RF04` (Reference Track `D-009H`), `HY01–HY05` (`DESIGN_REQUIRED`).

---

## 2. Leaderboard Validasi Protocol A (`n=3.060`, Ranking MAE Raw)

| Peringkat | Model | Raw MAE (µm) | Raw RMSE (µm) | Lin's CCC | R² | Clipped MAE (µm) | Pred. Negatif | Waktu Total (dtk) |
|---:|---|---:|---:|---:|---:|---:|---:|---:|
| 1 | `ML01` Extra Trees | **14,25** | 28,94 | 0,9796 | 0,9606 | 14,25 | 0 | 32,20 |
| 2 | `FM03` TabICLv2 (zero-shot) | **14,39** | 29,17 | 0,9794 | 0,9600 | 14,38 | 291 | 83,25 |
| 3 | `ML02` Random Forest | **14,56** | 29,87 | 0,9783 | 0,9580 | 14,56 | 0 | 95,88 |
| 4 | `ML04` XGBoost | **14,74** | 29,68 | 0,9786 | 0,9586 | 14,62 | 256 | 20,74 |
| 5 | `ML06` CatBoost | **14,98** | 29,05 | 0,9796 | 0,9603 | 14,86 | 203 | 29,48 |
| 6 | `ML05` LightGBM | **15,00** | 29,65 | 0,9787 | 0,9586 | 14,86 | 255 | 9,39 |
| 7 | `ML03` HistGradientBoosting | **15,24** | 30,15 | 0,9779 | 0,9572 | 15,16 | 143 | 9,19 |
| 8 | `DL03` RealMLP | **16,66** | 31,41 | 0,9762 | 0,9536 | 16,66 | 0 | 119,34 |
| 9 | `DL02` FT-Transformer | **16,73** | 31,36 | 0,9768 | 0,9537 | 16,26 | 578 | 188,22 |
| 10 | `RF05` DLM retrained | **17,49** | 33,68 | 0,9728 | 0,9466 | 17,45 | 25 | 22,95 |
| 11 | `SG06` MultiROCKET-HYDRA | **22,33** | 33,46 | 0,9730 | 0,9473 | 20,61 | 340 | 347,88 |
| 12 | `DL05` TabM | **23,52** | 41,36 | 0,9583 | 0,9195 | 23,12 | 184 | 24,02 |
| 13 | `DL04` TabR | **23,95** | 42,81 | 0,9548 | 0,9137 | 23,28 | 479 | 430,01 |
| 14 | `DL01` MLP | **24,21** | 46,34 | 0,9489 | 0,8990 | 24,15 | 89 | 15,83 |
| 15 | `SG05` ROCKET | **26,25** | 38,83 | 0,9631 | 0,9291 | 24,20 | 312 | 51,98 |
| 16 | `SG04` LITETime (`n_reg=1`) | **27,72** | 38,43 | 0,9638 | 0,9305 | 27,28 | 117 | 739,40 |
| 17 | `ML07` SVR RBF | **29,72** | 49,86 | 0,9366 | 0,8830 | 28,69 | 293 | 58,14 |
| 18 | `SG01` Vanilla 1D-CNN | **41,88** | 56,21 | 0,9168 | 0,8513 | 40,52 | 129 | 28,11 |
| 19 | `RF02` Linear Regression | **52,45** | 70,37 | 0,8722 | 0,7670 | 46,02 | 439 | 1,54 |
| 20 | `RF01` Dummy Mean | **120,27** | 145,79 | ~0,0000 | -0,0001 | 120,27 | 0 | 1,30 |

**Pembanding Historis (Provenance Terpisah — Tidak Independen terhadap Split Saat Ini):**
- `DLMwidth`: `MAE = 14,59 µm`, `RMSE = 27,14 µm`, `CCC = 0,9820`, `R² = 0,9653`.
- `AEDwidth`: `MAE = 33,21 µm`, `RMSE = 52,19 µm`, `CCC = 0,9288`, `R² = 0,8718`, `Bias = -23,28 µm`.

---

## 3. Interpretasi Ilmiah & Rekomendasi Finalis

1. **`FM03` (`TabICLv2`) menempati peringkat #2 secara zero-shot (`14,39 µm`)**, mengungguli seluruh model boosting (`ML04–ML06`), Random Forest (`ML02`), dan seluruh model deep learning tabular/spasial.
2. **Enam dari tujuh peringkat teratas diisi model tree/boosting (`ML01–ML06`, `14,25–15,24 µm`)** dengan waktu eksekusi cepat (`9–96 dtk`).
3. **Keterbatasan Protocol A:** Karena Protocol A melakukan split berdasarkan `gridline` (bukan `image`), kedekatan spasial dalam gambar yang sama dapat menguntungkan model berbasis partisi/in-context. Evaluasi **Protocol B (`Series + Image`)** di fase berikutnya sangat krusial untuk menguji generalisasi antar-gambar.
4. **Usulan Shortlist Finalis Multi-Paradigma:** `ML01`, `ML02`, `ML04`, `ML05`, `ML06`, `FM03`, `DL02`, `DL03`, `SG06` (+ `SG04`), serta jangkar referensi `RF05`, `RF02`, `RF01` (rincian di `M04A_PROPOSED_FINALIST_SHORTLIST.md`).

---

## TINDAKAN MANUAL PENELITI

1. **Instalasi Software:** Tidak ada instalasi paket atau software tambahan yang diperlukan. Seluruh 8 environment `.venv*` tidak berubah.
2. **Eksekusi Notebook Manual:** **Tidak diperlukan** — `notebooks/01_M04A_scientific_screening_analysis.ipynb` sudah dieksekusi otomatis menggunakan kernel `krkcmd-research-newpc` (output tersimpan di `reports/runs/M04A_20261126_145808_DESKTOP-CQB09OU/01_M04A_scientific_screening_analysis_executed.ipynb` dan `.html`).
3. **Akses Checkpoint / Lisensi:** Jika ingin menyertakan `FM01` / `FM02` (`TabPFN-3.5`) di tahap berikutnya, peneliti perlu menyetujui lisensi PriorLabs secara personal di `https://ux.priorlabs.ai` dan menyetel `TABPFN_TOKEN`.
4. **Aksi Git Aman:** Agen tidak menjalankan `git commit` atau `git push`. Peneliti dapat meninjau perubahan dan melakukan commit secara manual bila sudah sesuai.
5. **File yang Perlu Diunggah ke ChatGPT untuk Review:**
   1. `c:\PROJECT\krkCMd_research_starter_v1\for_review\result_run_11_M04A.md`
   2. `c:\PROJECT\krkCMd_research_starter_v1\reports\runs\M04A_20261126_145808_DESKTOP-CQB09OU\M04A_review_package.zip`
